package com.nucleus.brd3.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;


@Controller
public class UserController {

	@GetMapping("/")
	//@RequestMapping("/")
	public String homeScreen() 
	{
		
		return "home";
	}
	
	// add request mapping for /leaders

	@GetMapping("/userScreen")
	//@RequestMapping("/leaders")
	public String adminScreen() 
	{
		
		return "userPage";
	}
	
	// add request mapping for /systems
	
	@GetMapping("/adminScreen")
	//@RequestMapping("/systems")
	public String userScreen() 
	{
		
		return "adminPage";
	}
	
}

