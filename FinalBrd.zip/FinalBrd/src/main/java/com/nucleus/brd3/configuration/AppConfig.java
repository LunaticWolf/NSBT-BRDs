package com.nucleus.brd3.configuration;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

@Configuration
@EnableWebMvc
@ComponentScan(basePackages="org.nucleus.br3.configuration")
@PropertySource("classpath:persistence-oracle.properties")
public class AppConfig {

	@Autowired
	Environment env;
	
	@Bean
	public ViewResolver view()
	{

		InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
		
		viewResolver.setPrefix("/WEB-INF/view/");
		viewResolver.setSuffix(".jsp");
		
		return viewResolver;
	}
	
	@Bean
	public DataSource dataSource()
	{
		DriverManagerDataSource securedSource=new  DriverManagerDataSource();
		
		securedSource.setDriverClassName(env.getProperty("jdbc.driver"));
		
		securedSource.setUrl(env.getProperty("jdbc.url"));
		securedSource.setUsername(env.getProperty("jdbc.user"));
		securedSource.setPassword(env.getProperty("jdbc.password"));
	
		return securedSource;
	}

	
	
	
}
