Chapter 5's project is empty, mostly because Chapter 5 was focused
almost entirely on mapping concepts and not on actual coding
practices; the few places where coding would be appropriate have
already been shown in prior chapters.