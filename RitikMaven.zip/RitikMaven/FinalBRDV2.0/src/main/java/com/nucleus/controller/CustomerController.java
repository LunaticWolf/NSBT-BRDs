package com.nucleus.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.security.Principal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.reflect.TypeToken;
import com.nucleus.model.Customer;
import com.nucleus.service.ICustomerService;
@Controller
public class CustomerController {
	
	final static Logger logger = Logger.getLogger(com.nucleus.controller.CustomerController.class);
@Autowired
ICustomerService CustomerServiceImpl;


/////Insert

@RequestMapping("/InsertPage")
public ModelAndView handlerMethod( Customer customer)

{
	//String[] customerHobbies = {"Singing","dancing","tracking"};
	
	//customer.setCustomerHobbies(customerHobbies);
	
	//return new ModelAndView("insert","customerHobbies",customerHobbies);
	return new ModelAndView("insert");
}

@RequestMapping("/insertdone")
public ModelAndView Insert(@Valid Customer customer,BindingResult br,Principal principal,ModelAndView modelAndView,RedirectAttributes redirect)

{
	//System.out.println("IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII");
	/*if(br.hasErrors())
	{
		System.out.println("IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII797879879879879879879879879");	
		return new ModelAndView("insert");
		
	}*/
	
	/*else
	{*/
		Customer c=CustomerServiceImpl.view(customer);
		
		if(c!=null)
		{
			String msg="Code Already Exist";
			return new ModelAndView("insert","msg",msg);
		}
		else{
		
		
	String msg="Successfully Inserted";
	//System.out.println("\n p55555555555555ssppsps"+ customer.getCustomerEmail() + customer.getCustomerName());
	customer.setCreatedBy(principal.getName());
	CustomerServiceImpl.insert(customer);
	
	modelAndView.setViewName("redirect:InsertPage");
    redirect.addFlashAttribute("msg",msg);
	
	//return new ModelAndView("insert","msg",msg);
    return modelAndView;
	//}
	}
}
@RequestMapping("/DeletePage")
public String handlerMethod1( Customer customer)

{
	return "delete";

}

@RequestMapping("/deletedone")
public ModelAndView Delete( Customer customer)

{
	String msg="Successfully Deleted";
	CustomerServiceImpl.delete(customer);
	return  new ModelAndView("delete","msg",msg); 

}
@RequestMapping("/ViewPage")
public String handlerMethod2( Customer customer)

{
	return "retrieve";

}

@RequestMapping("/viewdone")
public ModelAndView View( Customer customer)

{
	Customer c=CustomerServiceImpl.view(customer);
	ModelAndView  model=new ModelAndView("view1");
    model.addObject("listContact",c);
   
 
    return model;
	

}

@RequestMapping("/UpdatePage")
public String handlerMethod3( Customer customer)

{
	
	return "update";

}

@RequestMapping("/updatedone")
public ModelAndView update( Customer customer)

{
	Customer c=CustomerServiceImpl.update(customer);
	ModelAndView  model=new ModelAndView("update1");
    model.addObject("listContact",c);
   
 
    return model;
	

}
@RequestMapping("/insert2done")
public ModelAndView insert2( Customer customer)

{
	
	
	String msg="Successfully Updated";
	System.out.println("\n MODIFIED DATE Controller before:- "+ new java.sql.Date(new Date().getTime()));
	customer.setModifiedDate( new java.sql.Date(new Date().getTime()));
	CustomerServiceImpl.insert(customer);
	System.out.println("\n MODIFIED DATE Controller After set:"+customer.getModifiedDate());
	return new ModelAndView("update1","msg",msg);
	
}

@RequestMapping(value="/ViewAll",method=RequestMethod.GET)
public ModelAndView viewall(Model model,HttpServletResponse response)
{
	List<Customer> customerList=CustomerServiceImpl.viewall();
	//model.addAttribute("list",list);
//	return new ModelAndView("ViewAllUser");
	
	
	/*Gson gson = new Gson();
	response.setContentType("application/json");
	
	JsonElement element = gson.toJsonTree(customerList, new TypeToken<List<Customer>>() {}.getType());
	JsonArray jsonArray = element.getAsJsonArray();
	String listData=jsonArray.toString();				
	//Return Json in the format required by jTable plugin
//	listData="{\"Result\":\"OK\",\"Records\":"+listData+"}";			
//	response.getWriter().print(listData);
	*/
	System.out.println("Customer LIST"+customerList.get(0).getCustomerAddress());
	
	return new ModelAndView("ViewAllUser","customerList",customerList);
}
///////////////////////////////////////////////////////


@RequestMapping(value="/NewFile",method=RequestMethod.GET)
public String handlerMethod9( )

{
	
	return "NewFile";

}


@RequestMapping(value="/ViewAllAjax",method=RequestMethod.GET)
public ModelAndView viewallusingAjax(Model model,HttpServletResponse response) throws IOException
{
	response.setContentType("text/xml");
	//responseObj.setHeader("Cache-Control", "no-cache");
	PrintWriter writer = response.getWriter();
	
	
	 
	List<Customer> customerList=CustomerServiceImpl.viewall();
	Iterator<Customer> itr =customerList.iterator();
	Customer customer =  new Customer(); 
	int id=0;
	 
    String html="";
 
      html="<Table border=1>";
 
      while(itr.hasNext())
 
      {
 
          customer=(Customer)customerList.get(id);
 
       html=html+"<tr border=1><td>";
 
       html=html+customer.getCustomerCode();
 
          html=html+"</td><td>";
 
          html=html+customer.getCustomerName();
 
       html=html+"</td><td>";
 
           html=html+customer.getCustomerAddress();
 
       html=html+"</td><td>";
 
           html=html+customer.getCustomerPincode();
 
       html=html+"</td><td>";
 
           html=html+customer.getCustomerEmail();
 
       html=html+"</td><td>";
 
       
//       
       
       
       html=html+customer.getContactNumber();

   html=html+"</td><td>";
   
   
   html=html+customer.getRegistrationDate();

   html=html+"</td><td>";
   
   
   html=html+customer.getCreatedBy();

   html=html+"</td><td>";
   
       
       //
       
       
       
       
       
           html=html+customer.getModifiedDate();
 
       html=html+"</td></tr>";
 
       id++;  
 
     itr.next();
 
      }
 
                                html=html+"</Table>";
 
      writer.println(html);
 
      writer.close();                   
      


	
	return new ModelAndView("ViewAllUser","customerList",customerList);
}// end of Ajax


/*catch(Exception ex){
		String error="{\"Result\":\"ERROR\",\"Message\":"+ex.getMessage()+"}";
		response.getWriter().print(error);
		ex.printStackTrace();
*/	//}				

	
	

	

	
	
}//end

