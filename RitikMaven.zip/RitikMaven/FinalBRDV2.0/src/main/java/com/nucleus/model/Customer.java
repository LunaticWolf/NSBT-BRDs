package com.nucleus.model;

import java.io.Serializable;
import java.sql.Date;
import java.util.List;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OrderColumn;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;
import org.springframework.beans.factory.annotation.Required;
@Entity(name="FinalBRDCustomer")
@Table(name="FinalBRDCustomer")
public class Customer implements Serializable {

	@Id
    
	 @NotNull
	   // @Size(max = 10)
	 
	private Integer customerCode;
	 @Length(max=30)
	 @NotNull
	 @Pattern(regexp="[a-zA-z ]+")
	private String customerName;
	// @Length(min=1, max=100)
	@NotNull
	private String customerAddress;
	@Length(min=6, max=6)
	 @Pattern(regexp="[0-9]+")
	 @NotNull
	private String customerPincode;
	 @Email
	private String customerEmail;
	 @Length(max=20)
	private String contactNumber;
	 @NotNull
	private Date registrationDate;
	 @NotNull
	private String createdBy;
	private Date modifiedDate;
	
	private String hobbies1;
	
	private String hobbies2;
	
	
	/*public int getCustomerCode() {
		return customerCode;
	}
	public void setCustomerCode(int customerCode) {
		this.customerCode = customerCode;
	}*/

	
	
	
	
	public String getCustomerName() {
		return customerName;
	}




	public String getHobbies1() {
		return hobbies1;
	}




	public void setHobbies1(String hobbies1) {
		this.hobbies1 = hobbies1;
	}




	public String getHobbies2() {
		return hobbies2;
	}




	public void setHobbies2(String hobbies2) {
		this.hobbies2 = hobbies2;
	}




	public Integer getCustomerCode() {
		return customerCode;
	}
	public void setCustomerCode(Integer customerCode) {
		this.customerCode = customerCode;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}
	public String getCustomerPincode() {
		return customerPincode;
	}
	public void setCustomerPincode(String customerPincode) {
		this.customerPincode = customerPincode;
	}
	public String getCustomerEmail() {
		return customerEmail;
	}
	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	
	public Date getRegistrationDate() {
		return registrationDate;
	}
	public void setRegistrationDate(Date registrationDate) {
		this.registrationDate = registrationDate;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}




	@Override
	public String toString() {
		return "Customer [customerCode=" + customerCode + ", customerName="
				+ customerName + ", customerAddress=" + customerAddress
				+ ", customerPincode=" + customerPincode + ", customerEmail="
				+ customerEmail + ", contactNumber=" + contactNumber
				+ ", registrationDate=" + registrationDate + ", createdBy="
				+ createdBy + ", modifiedDate=" + modifiedDate + ", hobbies1="
				+ hobbies1 + ", hobbies2=" + hobbies2 + "]";
	}


	

	

	
	
	
	

}
