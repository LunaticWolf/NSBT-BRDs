package com.nucleus.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nucleus.dao.ICustomerDAO;
import com.nucleus.model.Customer;



@Service
public class CustomerServiceImpl implements ICustomerService{
@Autowired
ICustomerDAO CustomerDAOImpl;
@Transactional
	public void insert(Customer customer) {
	
		CustomerDAOImpl.insert(customer);
	}
@Transactional
	public void delete(Customer customer) {
		CustomerDAOImpl.delete(customer);
		
	}
@Transactional
public Customer  view(Customer customer) {
	return	CustomerDAOImpl.view(customer);
	
}

@Transactional
public List<Customer> viewall() {
	
	return CustomerDAOImpl.viewall();
}
@Transactional
public Customer update(Customer customer) {
	
	return CustomerDAOImpl.update(customer);
}
@Transactional
public void insert2(Customer customer) {
	CustomerDAOImpl.insert2(customer);
	
}

}
