package com.nucleus.service;

import com.nucleus.model.User;


public interface UserService {

	public User adduser(User user);
}

