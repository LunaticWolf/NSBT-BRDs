package com.luv2code.springdemo.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.luv2code.springdemo.entity.Customer;

@Repository
public class CustomerDAOImpl implements CustomerDAO 
{

	@Autowired
	private SessionFactory sessionFactory;
			




    //View All..............................................................................................................
	@Override
	public List<Customer> getCustomers() 
	{
		
		
		Session session = sessionFactory.openSession();
				
		Query<Customer> theQuery = session.createQuery("from Customer",Customer.class);
		
		List<Customer> customers = theQuery.list();
				
		return customers;
	}





	//Save Data...............................................................................................................
	@Override
	public void saveCustomer(Customer theCustomer) 
	{

		Session session = sessionFactory.openSession();
		
		currentSession.saveOrUpdate(theCustomer);
		
	}



	


    //get Single Customer..............................................................................................
	@Override
	public Customer getCustomer(int theCustomerId) 
	{

		Session session = sessionFactory.openSession();
		
		Customer theCustomer = session.get(Customer.class, theCustomerId);
		
		return theCustomer;
	}



	


	//delete.............................................................................................................
	@Override
	public void deleteCustomer(int theCustomerId) 
	{


		Session session = sessionFactory.openSession();


		Customer theCustomer = session.get(Customer.class, theCustomerId);		
        
        session.delete(theCustomer);


		/*Query theQuery = 
				currentSession.createQuery("delete from Customer where id=:customerId");
		theQuery.setParameter("customerId", theId);
		
		theQuery.executeUpdate();*/		
	}







//Get Customer Single View................................................................................................
	@Override
	public List<Customer> searchCustomer(String theCustomerId) 
	{

		Session session = sessionFactory.openSession();
		List<Customer> customers = null;

		if (theCustomerId != null && theCustomerId.trim().length() > 0) 
		{

			List<Customer> customers = session.get(Customer.class, theCustomerId);

		}
		else
		{
			return customers;
        }
        
        return customers;
	}

}











