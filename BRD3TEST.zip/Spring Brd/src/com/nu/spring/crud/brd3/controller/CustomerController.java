package com.luv2code.springdemo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.luv2code.springdemo.entity.Customer;
import com.luv2code.springdemo.service.CustomerService;





@Controller
@RequestMapping("/customer")
public class CustomerController 
{


	@Autowired
	private CustomerService customerService;



	

	//List .........................................................................................<VIEW ALL>
	@GetMapping("/listCustomer")
	public String listCustomers(Model theModel) 
	{
		
		List<Customer> theCustomers = customerService.getCustomers();
				
		theModel.addAttribute("customers", theCustomers);
		
		return "list-customers";
	}


	




	//ADD------------------------------------------------------------------------------------------------<ADD>
	
	@GetMapping("/addCustomerForm")
	public String showFormForAdd(Model theModel) 
	{
		
		Customer theCustomer = new Customer();
		
		theModel.addAttribute("customer", theCustomer);
		
		return "customer-form";
	}
	
	






	//SAVE...................................................................................................<SAVE ADDED DATA>
	@PostMapping("/saveCustomer")
	public String saveCustomer(@ModelAttribute("customer") Customer theCustomer) 
	{
		
		customerService.saveCustomer(theCustomer);	
		
		return "redirect:/customer";
	}






	// Update...........................................................................

    @GetMapping("/updateSearch")
	public String updateCustomer(Model theModel) 
	{
		
		Customer theCustomer = new Customer();
		
		theModel.addAttribute("customer", theCustomer);
		
		return "search-id-update";
	}




	@GetMapping("/updateCustomerForm")
	public String updateForm(@RequestParam("theCustomerId") int theId,
									Model theModel) 
	{
		
		Customer theCustomer = customerService.getCustomer(theId);	
		
		theModel.addAttribute("customer", theCustomer);
		
		return "customer-form";
		//Then  Saved as ADD Form
	
	}
	
	




	//Delete.......................................................................................
 	@GetMapping("/deleteSearch")
	public String deleteSearch(Model theModel) 
	{
		
		Customer theCustomer = new Customer();
		
		theModel.addAttribute("customer", theCustomer);
		
		return "search-id-delete";
	}



	@GetMapping("/delete")
	public String deleteCustomer(@RequestParam("theCustomerId") int theCustomerId) 
	{
		
		customerService.deleteCustomer(theCustomerId);

		return "redirect:/customer";
		
		//return "redirect:/customer/list";
	}








//Single View........................................................................................................
	@GetMapping("/search")
	public String showCustomer(Model theModel) 
	{
		
		Customer theCustomer = new Customer();
		
		theModel.addAttribute("customer", theCustomer);
		
		return "search-id-view";
	}




 //Search ID..............................................................................................................
	@PostMapping("/searchCustomer")
	
	public String searchCustomers(@RequestParam("theCustomerId") String theCustomerId,Model theModel) 
	{
	//search 
	List<Customer> theCustomers = customerService.searchCustomer(theCustomerId);

	theModel.addAttribute("customers", theCustomers);
	
	return "list-customers"; 
	}
	
}








/*//GET ID.................................................................................................<GET ID>
    @PostMapping("/getId")
    public string getId(@RequestParam("customerId") int theId,@RequestParam("Command") String theCommand , Model theModel)  //gets ID
       {
       	customerService.getCustomer(theId);
       	


       	if(theCommand.equalsIgnoreCase("UPDATE"))
       	{
       		return "redirect:/customer/UpdateForm";
       	}

       	elseif(theCommand.equalsIgnoreCase("DELETE"))
         {
         	returm "redirect:/customer/deleteCustomer";
         }

         elseif(theCommand.equalsIgnoreCase("SINGLEVIEW"))
         {
         	return "redirect:/customer/singleView"
         }

       }*/