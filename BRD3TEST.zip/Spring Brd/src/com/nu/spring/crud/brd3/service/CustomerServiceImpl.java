package com.luv2code.springdemo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.luv2code.springdemo.dao.CustomerDAO;
import com.luv2code.springdemo.entity.Customer;

@Service
public class CustomerServiceImpl implements CustomerService 
{

	// need to inject customer dao
	@Autowired
	private CustomerDAO customerDAO;



//-----------------------------------------------------------------------------------------------------View all	
	@Override
	@Transactional
	public List<Customer> getCustomers()

	{
		return customerDAO.getCustomers();
	}

	




//---------------------------------------------------------------------------------------------------------------------Save Data

	@Override
	@Transactional
	public void saveCustomer(Customer theCustomer) 

	{

		customerDAO.saveCustomer(theCustomer);
	}

	



//Get ID...............................................................................................................GET ID

	@Override
	@Transactional
	public Customer getCustomer(int theCustomerId) 

	{
		
		return customerDAO.getCustomer(theCustomerId);
	}

	


//................................................................................................................DELETE
	@Override
	@Transactional
	public void deleteCustomer(int theCustomerId)

	{
		
		customerDAO.deleteCustomer(theId);
	}



//Search ID.............................................................................................................Search Id
	@Override
	@Transactional
	public List<Customer> searchCustomer(String theCustomerId) 
	{
		return customerDAO.searchCustomer(theCustomerId);
	}

}





