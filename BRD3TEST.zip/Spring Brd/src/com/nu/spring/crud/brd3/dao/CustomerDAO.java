package com.luv2code.springdemo.dao;

import java.util.List;

import com.luv2code.springdemo.entity.Customer;

public interface CustomerDAO 
{


	public List<Customer> getCustomers(); //VIEW

	public void saveCustomer(Customer theCustomer); //ADD/UPDATE

	public Customer getCustomer(int theCustomerId); //UPDATE

	public void deleteCustomer(int theCustomerId);  //DELETE

	public List<Customer> searchCustomer(String theCustomerId); //SINGLEVIEW 
	
}
