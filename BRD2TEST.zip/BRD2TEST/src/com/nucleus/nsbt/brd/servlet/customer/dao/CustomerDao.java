package com.nucleus.nsbt.brd.servlet.customer.dao;

import java.util.List;

import com.nucleus.nsbt.brd.servlet.customer.model.Customer;

public interface CustomerDao 
{

	Customer addCustomer(Customer newCustomer);

	List<Customer>  getCustomers();

	Customer getCustomerById(String customerCode);

	Customer updateCustomer(Customer thatCustomer);

	Customer deleteCustomer(String customerCode);

}
