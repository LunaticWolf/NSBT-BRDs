package com.nucleus.nsbt.brd.servlet.login.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="User_18060163")
public class User 
{
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="user_entry")
	private int userEntry;
	
	@Id
	@Column(name="user_id")
	private String userId;
	
	@Column(name="user_name")
	private String userName;
	
	@Column(name="user_password")
	private String userPassword;
	
	@Column(name="user_role")
	private String role;
	
	
	//Getters--------------------------------------------------------------------------------------------
	
	
	public String getUserId() {
		return userId;
	}
	public String getUserName() {
		return userName;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public String getRole() {
		return role;
	}
	
	
	//Setters--------------------------------------------------------------------------------------------
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	public void setRole(String role) {
		this.role = role;
	}

	
	
	//Constructor------------------------------------------------------------------------------------------------------------------
	public User(String userId, String userName, String userPassword, String role) 
	{
		super();
		this.userId = userId;
		this.userName = userName;
		this.userPassword = userPassword;
		this.role = role;
	}
	
	
	//to String--------------------------------------------------------------------------------------------------------------------
	public User() {}
	public User(String userId, String userName, String role) 
	{
		super();
		this.userId = userId;
		this.userName = userName;
		this.role = role;
	}
	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + ", userPassword=" + userPassword + ", Role=" + role
				+ "]";
	}
	
	

	
	
}
