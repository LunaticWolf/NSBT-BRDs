package com.nucleus.nsbt.brd.servlet.login.dao;

import com.nucleus.nsbt.brd.servlet.login.model.User;

public interface LoginDao 
{
   public User ValidateLogin(String userId,String password);
   public User registerUser(User theUser);
}
