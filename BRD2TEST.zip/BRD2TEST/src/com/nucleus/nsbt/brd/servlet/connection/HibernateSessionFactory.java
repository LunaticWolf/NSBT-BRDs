package com.nucleus.nsbt.brd.servlet.connection;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

@SuppressWarnings("deprecation")
public class HibernateSessionFactory 
{
	
	private static SessionFactory factory = null;
	
	private HibernateSessionFactory() {}
	
	@SuppressWarnings("finally")
	public static SessionFactory getSessionFactory()
	{
	
		try
		{
			factory = new AnnotationConfiguration().configure().buildSessionFactory();
		
			return factory;
		}
		catch(HibernateException e)
		{
			System.out.println("Couldn't Establish Database Connection");
			e.printStackTrace();
		}
		finally
		{
			return factory;
		}
	}

}
