package com.nucleus.nsbt.brd.servlet.customer.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.nucleus.nsbt.brd.servlet.customer.model.Customer;

public class CustomerDaoImpl implements CustomerDao 
{
	//initialization 
	Session session = null;
    Transaction transaction= null;
	
    
    
    //get session------------------------------------------------------------------
	public CustomerDaoImpl(SessionFactory factory)
   {
	  session = factory.openSession();
   }



	@Override
	public Customer addCustomer(Customer newCustomer) 
	{
		transaction = session.getTransaction();
		
		try
		{
			transaction.begin();
			
			session.save(newCustomer);
			
			transaction.commit();
		}
		catch(HibernateException e)
		{
			System.out.println("Couldn't ADD Record to Database");
			e.printStackTrace();
			transaction.rollback();
		}
		
		finally
		{
			sessionClose();
		}
		return newCustomer;
	}


	
	
	
	
	
//Close Session------------------------------------------------------------------------------------------------
	
	private void sessionClose() 
	{
		if(session!=null)
			session.close();
	}



	
	
	@Override
	public List<Customer> getCustomers() 
	{
		
		transaction = session.getTransaction();
		List<Customer> customers = null;
		try
		{
			transaction.begin();
			Query query = session.createQuery("from customer");
			
			customers = query.list();
			
			transaction.commit();
			return customers;
			
		}
		catch(HibernateException e)
		{
			System.out.println("Couldn't Display Data from Database");
			e.printStackTrace();
			transaction.rollback();
		}
		
		finally
		{
			sessionClose();
		}
		
		return customers;
		
		
	}



	@Override
	public Customer getCustomerById(String customerCode) 
	{
		transaction = session.getTransaction();
		Customer theCustomer = null;
		
		try
		{
		  transaction.begin();
		  
		  theCustomer = (Customer) session.get(Customer.class, customerCode);
		  
		  transaction.commit();
		}
		catch(HibernateException e)
		{
			System.out.println("Searching Id for update thorws exception");
			transaction.rollback();
			e.printStackTrace();
		}
		finally
		{
			sessionClose();
		}
		return theCustomer;
	}



	@Override
	public Customer updateCustomer(Customer thatCustomer) 
	{
		transaction = session.getTransaction();
		Customer theCustomer = null;
	
		try
		{
			transaction.begin();
			String customerCode = thatCustomer.getCustomercode();
			
			theCustomer = (Customer) session.get(Customer.class, customerCode);
			
			if(theCustomer!=null)
			{
				theCustomer.setCustomerName(thatCustomer.getCustomerName());
				theCustomer.setCustomerAddress1(thatCustomer.getCustomerAddress1());
				theCustomer.setCustomerAddress2(thatCustomer.getCustomerAddress2());
				theCustomer.setCustomerPincode(thatCustomer.getCustomerPincode());
				theCustomer.setCustomerEmail(thatCustomer.getCustomerEmail());
				theCustomer.setCustomerContactNumber(thatCustomer.getCustomerContactNumber());
				theCustomer.setCustomerPrimaryContactPerson(thatCustomer.getCustomerPrimaryContactPerson());
				theCustomer.setCustomerRecordStatus(thatCustomer.getCustomerRecordStatus());
				theCustomer.setCustomerFlagStatus(thatCustomer.getCustomerFlagStatus());
				
				theCustomer.setModifiedDate(thatCustomer.getModifiedDate());
				theCustomer.setModofiedby(thatCustomer.getModofiedBy());
				
				theCustomer.setAuthorizedDate(thatCustomer.getAuthorizedDate());
				theCustomer.setAuthorizedBy(thatCustomer.getAuthorizedBy());
				
				
				transaction.commit();
			}
		}
		catch(HibernateException e)
		{
			System.out.println("Updating threws exception");
			transaction.rollback();
			e.printStackTrace();
		}
		finally
		{
			sessionClose();
		}
		return theCustomer;
	}



	@Override
	public Customer deleteCustomer(String customerCode) 
	{
		transaction = session.getTransaction();
		Customer theCustomer = null;
		try
		{
			transaction.begin();
			theCustomer = (Customer) session.get(Customer.class, customerCode);
			
			if(theCustomer!=null)
			{
				session.delete(theCustomer);
				
			}
	
			
			transaction.commit();
			return theCustomer; 
		}
		catch(HibernateException e)
		{
			System.out.println("Deleteting Id - " + customerCode +"  thorws exception");
			transaction.rollback();
			e.printStackTrace();
		}
		finally
		{
			sessionClose();
		}
		return theCustomer;
		
	}



	
	

	
	
	
	
}
