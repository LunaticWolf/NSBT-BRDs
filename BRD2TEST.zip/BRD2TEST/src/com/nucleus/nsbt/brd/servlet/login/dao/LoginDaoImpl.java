package com.nucleus.nsbt.brd.servlet.login.dao;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.nucleus.nsbt.brd.servlet.login.model.User;

public class LoginDaoImpl implements LoginDao
{
    
	
	//initialization 
	Session session = null;
    Transaction transaction= null;
	
    
    
    //get session------------------------------------------------------------------
	public LoginDaoImpl(SessionFactory factory)
   {
	  session = factory.openSession();
   }
	
	
	
	
	
	//Validate Log-in---------------------------------------------------------------------------------------------------
	  public User ValidateLogin(String userId,String password)
	  {
		  transaction = session.getTransaction();
		  User theUser = null;

		   try
		   {
			   
			   transaction.begin();
			   
			   theUser = (User) session.get(User.class, userId);
			   if(theUser==null)
			   {
				   System.out.println("UserId - "+ userId + "Doesn't Exits...");
				   return null;
			   }
			   
			   
			   if(!((theUser.getUserPassword()).equals(password)))
			   {
				   System.out.println("Password Missmatch");
				   return null;
			   }
			   
			   else
			   {
				   transaction.commit();
				   //here, 
				   //Should Not return Password data--------------------------------------------------------------
				   return theUser;
			   }
			   
			   
		   }
		   
		   catch(Exception e)
		   {
			   System.out.println("UserId Exception while Logging In");
			   transaction.rollback();
			   e.printStackTrace();
		   }
		  
		   finally
		   {
			   sessionClose();
		   }
		  
		  
		  return null;
	  }





	  

//Register New User-----------------------------------------------------------------------------------
	  public User registerUser(User theUser)
	  {
		  
		  transaction = session.getTransaction();
		  
		  try
		  {
				transaction.begin();
			  
				session.save(theUser);
			  
				transaction.commit();
			  
				return theUser;
		  }
		  
		  catch(Exception e)
		  {
			  System.out.println("Couldn't save New User");
			  transaction.rollback();
			  e.printStackTrace();
			  return null;
		  }
		  
		  finally
		  {
			  sessionClose();
		  }
		  
	  }



//Close Session----------------------------------------------------------------------------------------------------
	  private void sessionClose() 
	  {
		  if(session!=null)
		  {
			  session.close();
		  }
	  }


}