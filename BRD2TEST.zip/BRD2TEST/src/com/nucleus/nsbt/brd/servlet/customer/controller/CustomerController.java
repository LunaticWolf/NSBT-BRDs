package com.nucleus.nsbt.brd.servlet.customer.controller;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.SessionFactory;

import com.nucleus.nsbt.brd.servlet.customer.dao.CustomerDao;
import com.nucleus.nsbt.brd.servlet.customer.dao.CustomerDaoImpl;
import com.nucleus.nsbt.brd.servlet.customer.model.Customer;


@WebServlet("/CustomerController")
public class CustomerController extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
    
	SessionFactory factory = null;
	private HttpSession httpSession = null;
   
    public CustomerController() 
    {
        super();
    }
    
    
  
    
 //Get H-init Factory---------------------------------------------------------------------------------------------------
    
    
    @Override
  	public void init(ServletConfig config) throws ServletException 
  	{
  		super.init(config);
  		factory = (SessionFactory) this.getServletContext().getAttribute("FACTORY");

  	}

	
    
    //Do get-----------------------------------------------------------------------------------------------------------------
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
	   String page="Home.jsp";
	   String theCommand = request.getParameter("theCommand");
	   System.out.println("Customer Controller../nCommand -  " + theCommand);
	   
	   switch(theCommand)
	   {
		   case"ADD": page="add-customer.jsp";
		              System.out.println("1> Do GET...To Add Record Page");
			   break;
		 
		   
		   case"SINGLEVIEW" : page="search-id-view.html";
		   				      System.out.println("2> Do Get... TO View Particular Record Page");
		   break;
		   
		   case"UPDATE": page="search-update-id.html";
		   				 System.out.println("2> Do Get... TO Update Id Page");
		   break;
	
		   case"DELETE": page="search-delete-id.html";
		   				 System.out.println("2> Do Get... TO Delete - Id Page");	
		   break;
		   
		   default: page="Home.jsp";
	   }
	   
	   pageRequestDispatcher(request, response, page);
		
	}

	
	
	
	
	
	
	//Page Dispatcher--------------------------------------------------------------------------------------------------------
	
	private void pageRequestDispatcher(HttpServletRequest request, HttpServletResponse response, String page)
			throws ServletException, IOException {
		RequestDispatcher requestDispatcher = request.getRequestDispatcher(page);
		   requestDispatcher.forward(request, response);
	}

	
	
	
	
	
	
	
	//Do POST --------------------------------------------------------------------------------------------------------------
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		   String page="Home.jsp";
		   String theCommand = request.getParameter("theCommand");
		   System.out.println("Customer Controller../nCommand -  " + theCommand);
		   
		   
		   switch(theCommand)
		   {
			   case"ADD": addCustomer(request,response,page);
			   break;
				   
			   
			   case"MULTIVIEW": listCustomers(request,response,page);
			   break;
			   
			   case"SINGLEVIEW": getCustomerId(request, response, page);
			   					page = "single-view.jsp";
			   					//Create A Single Page For Update, Delete, And Single Record View or merge it with View All
				   
			   case"UPDATE-ID": getCustomerId(request,response,page);
			   					page="update-customer.html";
			   break;
				   
			   case"UPDATE": updateCustomer(request,response,page);
			   break;
			   
			   case"DELETE": deleteCustomer(request,response,page);
			   break;
			   
			   default: page="Home.jsp";
			   
		   }
		   
		   pageRequestDispatcher(request, response, page);
		
	}


	
	
	
	//View ALL-------------------------------------------------------------------------------------------------------------------------------
	
	private void listCustomers(HttpServletRequest request, HttpServletResponse response, String page) 
	{
		
		CustomerDao dao = new CustomerDaoImpl(factory);
		
		List<Customer> customers = dao.getCustomers(); 
		
		httpSession = request.getSession();
		httpSession.setAttribute("CUSTOMER_LIST", customers);
		
		page = "list-customers.jsp";
		
	}


//ADD------------------------------------------------------------------------------------------------------------------------------------
	
	
	private void addCustomer(HttpServletRequest request, HttpServletResponse response, String page) 
	{
	   
		//get Parameters------------------------------------------------------------------------------------------
		
		String customerCode = request.getParameter("customerCode");
		String customerName = request.getParameter("customerName");
		String customerAddress1 = request.getParameter("customerAddress1");
		String customerAddress2 = request.getParameter("customerAddress2");
		
		int customerPinCode = Integer.parseInt(request.getParameter("customerPinCode"));
		String customerEmail = request.getParameter("customerEmail");
		int customerContactNumber = Integer.parseInt(request.getParameter("customerContactNumber"));
		
		String customerPrimaryContactPerson = request.getParameter("customerPrimaryContactPerson");
		String customerRecordStatus = request.getParameter("customerRecordStatus");
		String customerFlagStatus = request.getParameter("customerFlagStatus");
		
		String createdDate = new Date().toString();
		String createdBy = request.getParameter("userName");
		String modifiedDate = "-";
		String modifiedBy = "-";
		String authorizedDate = "-";
		String authorizedBy = "-";
		
		
		//Wrap Data into Object-----------------------------------------------------------------------------------
		
		Customer newCustomer = new Customer(customerCode, customerName, customerAddress1, customerAddress2, customerPinCode,
				                customerEmail, customerContactNumber, customerPrimaryContactPerson, customerRecordStatus,
				                customerFlagStatus, createdDate, createdBy, modifiedDate, modifiedBy, authorizedDate, authorizedBy);
		
		
		//get Session
		CustomerDao dao = new CustomerDaoImpl(factory);
		
		//call method
		Customer theCustomer = dao.addCustomer(newCustomer);
		
		//httpsession
		httpSession = request.getSession();
		httpSession.setAttribute("CUSTOMER", theCustomer);
		
		page="single-view.jsp";
		
	}

	
	
	//Update----------------------------------------------------------------------------------------------------------------------
	private void updateCustomer(HttpServletRequest request, HttpServletResponse response, String page) 
	{
		
		String customerCode = request.getParameter("customerCode");
		String customerName = request.getParameter("customerName");
		String customerAddress1 = request.getParameter("customerAddress1");
		String customerAddress2 = request.getParameter("customerAddress2");
		
		int customerPinCode = Integer.parseInt(request.getParameter("customerPinCode"));
		String customerEmail = request.getParameter("customerEmail");
		int customerContactNumber = Integer.parseInt(request.getParameter("customerContactNumber"));
		
		String customerPrimaryContactPerson = request.getParameter("customerPrimaryContactPerson");
		String customerRecordStatus = request.getParameter("customerRecordStatus");
		String customerFlagStatus = request.getParameter("customerFlagStatus");
		
		
		String modifiedDate = new Date().toString();
		String modifiedBy = request.getParameter("userName");
		String authorizedDate = "-";
		String authorizedBy = "-";
		
		Customer thatCustomer = new Customer(customerCode, customerName, customerAddress1, customerAddress2, customerPinCode,
                customerEmail, customerContactNumber, customerPrimaryContactPerson, customerRecordStatus,
                customerFlagStatus, modifiedDate, modifiedBy, authorizedDate, authorizedBy);
		
		
		
		CustomerDao dao = new CustomerDaoImpl(factory);
		Customer theCustomer = dao.updateCustomer(thatCustomer);
		
		httpSession = request.getSession();
		httpSession.setAttribute("CUSTOMER", theCustomer);
		
		page="single-view.jsp";
	}




	


//Delete-----------------------------------------------------------------------------------------------------------------------------
	
	private void deleteCustomer(HttpServletRequest request, HttpServletResponse response, String page) 
	{
		String customerCode = request.getParameter("customerCode");
		
		CustomerDao dao = new CustomerDaoImpl(factory);
		
		Customer thecustomer = dao.deleteCustomer(customerCode); 
		
		httpSession = request.getSession();
		httpSession.setAttribute("CUSTOMER", thecustomer);
		
	}

	

//Get ID-------------------------------------------------------------------------------------------------------------------------
private void getCustomerId(HttpServletRequest request, HttpServletResponse response, String page) 
{
	String customerCode = request.getParameter("customerCode");
	
    
	CustomerDao dao = new CustomerDaoImpl(factory);
    
    Customer theCustomer = dao.getCustomerById(customerCode);
    
    httpSession = request.getSession();
    httpSession.setAttribute("CUSTOMER", theCustomer);
    
    
	
}

}