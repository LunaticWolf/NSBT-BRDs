package com.nucleus.nsbt.brd.servlet.connection;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;


public class HibernateSessionFactoryListner implements ServletContextListener 
{
    
	private SessionFactory factory = null;

	
    public HibernateSessionFactoryListner() {}

    
    public void contextDestroyed(ServletContextEvent listen)  
    { 
     
    	listen.getServletContext().removeAttribute("FACTORY");
    	
    	if(factory!=null)
    		factory.close();
    }

	
    public void contextInitialized(ServletContextEvent listen)  
    { 
          try
          {
    		factory = HibernateSessionFactory.getSessionFactory();
           
          if(factory!=null)
          {
        	  System.out.println("Init H-Factory Established");
    		listen.getServletContext().setAttribute("FACTORY", factory);
          }
           
          }
          catch(HibernateException e)
          {
        	  System.out.println("Couldn't Establish H-Factory");
        	  e.printStackTrace();
          }
    }
	
}
