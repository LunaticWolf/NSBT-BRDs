package com.nucleus.nsbt.brd.servlet.customer.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Customer 
{
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int customerId;

	@Id
	@Column(name="customer_code")
	private String customerCode;
	
	@Column(name="customer_name")
	private String customerName;
	
	@Column(name="customer_address1")
	private String customerAddress1;
	
	@Column(name="customer_address2")
	private String customerAddress2;
	
	@Column(name="customer_pincode")
	private int customerPincode;
	
	@Column(name="customer_email")
	private String customerEmail;
	
	@Column(name="customer_contact_number")
	private int customerContactNumber;
	
	@Column(name="customer_primary_contact_person")
	private String customerPrimaryContactPerson;
	
	@Column(name="customer_record_status")
	private String customerRecordStatus;
	
	@Column(name="customer_flag_status")
	private String customerFlagStatus;
	
	@Column(name="created_date")
	private String createdDate;
	
	@Column(name="created_by")
	private String createdBy;
	
	@Column(name="modified_date")
	private String modifiedDate;
	
	@Column(name="modified_by")
	private String modifiedBy;
	
	@Column(name="authorized_date")
	private String authorizedDate;
	
	@Column(name="authorized_by")
	private String authorizedBy;

	
	
	
	
	
	//Getters--------------------------------------------------------------------------------------------
	public int getCustomerId() {
		return customerId;
	}

	public String getCustomercode() {
		return customerCode;
	}

	public String getCustomerName() {
		return customerName;
	}

	public String getCustomerAddress1() {
		return customerAddress1;
	}

	public String getCustomerAddress2() {
		return customerAddress2;
	}

	public int getCustomerPincode() {
		return customerPincode;
	}

	public String getCustomerEmail() {
		return customerEmail;
	}

	public int getCustomerContactNumber() {
		return customerContactNumber;
	}

	public String getCustomerPrimaryContactPerson() {
		return customerPrimaryContactPerson;
	}

	public String getCustomerRecordStatus() {
		return customerRecordStatus;
	}

	public String getCustomerFlagStatus() {
		return customerFlagStatus;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public String getModofiedBy() {
		return modifiedBy;
	}

	public String getAuthorizedDate() {
		return authorizedDate;
	}

	public String getAuthorizedBy() {
		return authorizedBy;
	}

	
	
	
	
	//Setters-----------------------------------------------------------------------------------------------------
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public void setCustomercode(String customercode) {
		this.customerCode = customercode;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public void setCustomerAddress1(String customerAddress1) {
		this.customerAddress1 = customerAddress1;
	}

	public void setCustomerAddress2(String customerAddress2) {
		this.customerAddress2 = customerAddress2;
	}

	public void setCustomerPincode(int customerPincode) {
		this.customerPincode = customerPincode;
	}

	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}

	public void setCustomerContactNumber(int customerContactNumber) {
		this.customerContactNumber = customerContactNumber;
	}

	public void setCustomerPrimaryContactPerson(String customerPrimaryContactPerson) {
		this.customerPrimaryContactPerson = customerPrimaryContactPerson;
	}

	public void setCustomerRecordStatus(String customerRecordStatus) {
		this.customerRecordStatus = customerRecordStatus;
	}

	public void setCustomerFlagStatus(String customerFlagStatus) {
		this.customerFlagStatus = customerFlagStatus;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public void setModofiedby(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public void setAuthorizedDate(String authorizedDate) {
		this.authorizedDate = authorizedDate;
	}

	public void setAuthorizedBy(String authorizedBy) {
		this.authorizedBy = authorizedBy;
	}
	
	
	
	
	//Constructor-----------------------------------------------------------------------------------------------

	public Customer(int customerId, String customerCode, String customerName, String customerAddress1,
			String customerAddress2, int customerPincode, String customerEmail, int customerContactNumber,
			String customerPrimaryContactPerson, String customerRecordStatus, String customerFlagStatus,
			String createdDate, String createdBy, String modifiedDate, String modifiedBy, String authorizedDate,
			String authorizedBy) {
		super();
		this.customerId = customerId;
		this.customerCode = customerCode;
		this.customerName = customerName;
		this.customerAddress1 = customerAddress1;
		this.customerAddress2 = customerAddress2;
		this.customerPincode = customerPincode;
		this.customerEmail = customerEmail;
		this.customerContactNumber = customerContactNumber;
		this.customerPrimaryContactPerson = customerPrimaryContactPerson;
		this.customerRecordStatus = customerRecordStatus;
		this.customerFlagStatus = customerFlagStatus;
		this.createdDate = createdDate;
		this.createdBy = createdBy;
		this.modifiedDate = modifiedDate;
		this.modifiedBy = modifiedBy;
		this.authorizedDate = authorizedDate;
		this.authorizedBy = authorizedBy;
	}
	
	
	

	public Customer(String customerCode, String customerName, String customerAddress1, String customerAddress2,
			int customerPincode, String customerEmail, int customerContactNumber,
			String customerPrimaryContactPerson, String customerRecordStatus, String customerFlagStatus,
			String createdDate, String createdBy, String modifiedDate, String modofiedBy, String authorizedDate,
			String authorizedBy) {
		super();
		this.customerCode = customerCode;
		this.customerName = customerName;
		this.customerAddress1 = customerAddress1;
		this.customerAddress2 = customerAddress2;
		this.customerPincode = customerPincode;
		this.customerEmail = customerEmail;
		this.customerContactNumber = customerContactNumber;
		this.customerPrimaryContactPerson = customerPrimaryContactPerson;
		this.customerRecordStatus = customerRecordStatus;
		this.customerFlagStatus = customerFlagStatus;
		this.createdDate = createdDate;
		this.createdBy = createdBy;
		this.modifiedDate = modifiedDate;
		this.modifiedBy = modofiedBy;
		this.authorizedDate = authorizedDate;
		this.authorizedBy = authorizedBy;
	}

	
	//Without created date/by
	public Customer(String customerCode, String customerName, String customerAddress1, String customerAddress2,
			int customerPincode, String customerEmail, int customerContactNumber,
			String customerPrimaryContactPerson, String customerRecordStatus, String customerFlagStatus,
			String modifiedDate, String modifiedBy, String authorizedDate, String authorizedBy) 
	{
		this.customerCode = customerCode;
		this.customerName = customerName;
		this.customerAddress1 = customerAddress1;
		this.customerAddress2 = customerAddress2;
		this.customerPincode = customerPincode;
		this.customerEmail = customerEmail;
		this.customerContactNumber = customerContactNumber;
		this.customerPrimaryContactPerson = customerPrimaryContactPerson;
		this.customerRecordStatus = customerRecordStatus;
		this.customerFlagStatus = customerFlagStatus;
		
		this.modifiedDate = modifiedDate;
		this.modifiedBy = modifiedBy;
		this.authorizedDate = authorizedDate;
		this.authorizedBy = authorizedBy;	
	}

	//To String ---------------------------------------------------------------------------------------------------------------
	@Override
	public String toString() 
	{
		return "Customer [customerId=" + customerId + ", customercode=" + customerCode + ", customerName="
				+ customerName + ", customerAddress1=" + customerAddress1 + ", customerAddress2=" + customerAddress2
				+ ", customerPincode=" + customerPincode + ", customerEmail=" + customerEmail
				+ ", customerContactNumber=" + customerContactNumber + ", customerPrimaryContactPerson="
				+ customerPrimaryContactPerson + ", customerRecordStatus=" + customerRecordStatus
				+ ", customerFlagStatus=" + customerFlagStatus + ", createdDate=" + createdDate + ", createdBy="
				+ createdBy + ", modifiedDate=" + modifiedDate + ", modofiedby=" + modifiedBy + ", authorizedDate="
				+ authorizedDate + ", authorizedBy=" + authorizedBy + "]";
	}

	
	
}
