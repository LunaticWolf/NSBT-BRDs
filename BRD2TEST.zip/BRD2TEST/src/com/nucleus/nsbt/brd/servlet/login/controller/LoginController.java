package com.nucleus.nsbt.brd.servlet.login.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.SessionFactory;

import com.nucleus.nsbt.brd.servlet.login.dao.LoginDao;
import com.nucleus.nsbt.brd.servlet.login.dao.LoginDaoImpl;
import com.nucleus.nsbt.brd.servlet.login.model.User;




@WebServlet("/LoginController")
public class LoginController extends HttpServlet 
{
	
	//Initial Fields-----------------------------------------------------------------------------------------------------------------------------
	
	private static final long serialVersionUID = 1L;
	SessionFactory factory=null;
	private HttpSession httpSession=null;
      
	
    public LoginController() 
    {
        super();
    }
    
    
    
    
    
    
//Factory Init-Listner---------------------------------------------------------------------------------------------------------------------------
   
    
    
    @Override
	public void init(ServletConfig config) throws ServletException 
	{
		super.init(config);
		factory = (SessionFactory) this.getServletContext().getAttribute("FACTORY");

	}

    
    

//Do Get------------------------------------------------------------------------------------------------------------------------------------------
	
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{

		String theCommand = request.getParameter("theCommand");
		System.out.println("1. Get page - " + theCommand);
		
		String page = "LoginHome.html";
		
		switch(theCommand)
		{
		
			case"LOGIN":  page="login.html";
						  System.out.println("2. DoGet --> To Login Page");
			break;
			
			
			case"SIGNUP": page="register.html";
			              System.out.println("2. Doget --> To Register Page");
			break;               
		
			
			default:       page="LoginHome.html";
						   System.out.println("2. Doget --> To Default Page");
		}
		
		pageRequestDispatcher(request, response, page);
		
	}

	
    
    
    
	
//Page Dispatcher---------------------------------------------------------------------------------------------------------------------------------- 

    
    
    
    private void pageRequestDispatcher(HttpServletRequest request, HttpServletResponse response, String page)
			throws ServletException, IOException {
		RequestDispatcher requestDispatcher = request.getRequestDispatcher(page);
		requestDispatcher.forward(request, response);
	}

	
	
	
	
	
	
//Do Post---------------------------------------------------------------------------------------------------------------------------------------------	
	
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String theCommand = request.getParameter("theCommand");
		String page = "err.html";
		
		switch(theCommand)
		{
		
			case"LOGIN": 	System.out.println("To login control");
							login(request,response,page);
			break;
			
			case"REGISTER": System.out.println("To register control");
							register(request,response,page);
			break;
			
			default: page="LoginHome.html";
		
		}		
		
		pageRequestDispatcher(request, response, page);
						

	}


	
	
	

//Login Sub-Control------------------------------------------------------------------------------------------------------------------------------
	private void login(HttpServletRequest request, HttpServletResponse response,String page) throws ServletException, IOException 
	{
		
		//get parameters-------------------------------------------------------------
		String userId = request.getParameter("userId");
		String userPassword = request.getParameter("userPassword");
		
		
		//get Hibernate factory object-----------------------------------------------
		LoginDao dao = new LoginDaoImpl(factory);
		
		
		//validate user from database------------------------------------------------
	    User theUser = dao.ValidateLogin(userId, userPassword);
	    
	    
	    if(theUser!=null)
	    {
	    	//get httpSession, set attribute to dispatch data from controller to jsp page---------------------
	    	httpSession = request.getSession();
	    	httpSession.setAttribute("USER", theUser);
	    	
	    	String Role = theUser.getRole();
	    	
	    	if(Role.equalsIgnoreCase("Maker"))
	    	{
	    		System.out.println("Welcome Maker");
	    		page="Home.jsp";
	    	}
	    	
	    	if(Role.equalsIgnoreCase("Checker"))
	    	{
	    		System.out.println("Welcome Checker");
	    		page = "welcome-checker.jsp";
	    		
	    	}
	    
	    }
	    
	    else
	    {
	    	System.out.println("No User Found");
	    	page = "err.html";
	    }
		pageRequestDispatcher(request, response, page);
	}




private void register(HttpServletRequest request, HttpServletResponse response, String page) throws ServletException, IOException 
{
	String userId = request.getParameter("userId");
	System.out.println("user-Id - "+ userId);
	
	String userName = request.getParameter("userName");
	System.out.println("userName - "+ userName );
	
	String userPassword = request.getParameter("userPassword");
	System.out.println("userPassword - "+ userPassword );
	
	String userRole = request.getParameter("userRole");
	System.out.println("userRole - "+ userRole );
	
    String permission = request.getParameter("OTP");
    System.out.println("permission - "+ permission );
    
	if(permission!=null)
	{
			User newUser = new User(userId,userName,userPassword,userRole);
			
			LoginDao dao = new LoginDaoImpl(factory);
			
			User theUser = dao.registerUser(newUser);
			
			if(theUser!=null)
			{
				System.out.println("Registration Successfull");
				
				httpSession = request.getSession();
				httpSession.setAttribute("User", theUser);
				
				page = "login.html";
			}
	}
	
	else
		{
				System.out.println("Couldn't Sign Up");
				page = "register.html";
		}
	
	//pageRequestDispatcher(request, response, page);
	
}
}