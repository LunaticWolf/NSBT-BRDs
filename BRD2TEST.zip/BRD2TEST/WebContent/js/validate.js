function validateform(){
		var Code = document.addform.customercode.value;
		var Name = document.addform.customername.value;
		var Address1 = document.addform.address1.value;
		var Pincode1 = document.addform.pincode.value;
		var Email = document.addform.email.value;
		var customerPcp = document.addform.contactperson.value;
		var customerContact=document.addform.contact.value;
		var name_regex = /^[a-zA-Z0-9\\s]+/;
		var email_regex = /^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$/;
		var pincode_regex = /^[0-9]/;
		
		if(Code.length > 0){
			if(Name.length > 0 && Name.match(name_regex)){
				if(Address1.length > 0){
					if(Pincode1.length == 6 && Pincode1.match(pincode_regex)){
						if(Email.length > 0 && Email.match(email_regex)){
							if(customerPcp.length > 0){
								if(customerContact.length==10){
								  return true;
							}
								else
									{
									alert("Contact Number invalid");
									return false;
									}
									}
							else
							{
								alert("Primary contact person cannot be blank");
								return false;
							}
						}
						else{
							alert("Please Enter Valid email");
							return false;
						}
					}
					else{
						alert("Please Enter Valid pincode");
						return false;
					}
				}
				else{
					alert("Address1-> blank");
					return false;
				}
			}
			else{
				alert("Please Enter a valid Name");
				return false;
			}
		}
		else{
			alert("Customer Code Error");
			return false;
		}
	}
	