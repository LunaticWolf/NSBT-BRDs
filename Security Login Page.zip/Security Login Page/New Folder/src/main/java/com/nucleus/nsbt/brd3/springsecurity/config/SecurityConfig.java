package com.nucleus.nsbt.brd3.springsecurity.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;


/*import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.User.UserBuilder;*/

@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter 
{

	// Security dataSource
	@Autowired
	private DataSource securityDataSource;
	
	
	
	//Method 1
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception 
	{
		
		auth.jdbcAuthentication().dataSource(securityDataSource);

		
		//inmemoryAuth
	}

	
	//Method 2
	@Override
	protected void configure(HttpSecurity http) throws Exception 
	{

		http.authorizeRequests()
			.antMatchers("/").hasRole("NUCLEITE")
			.antMatchers("/userScreen/**").hasRole("USER")
			.antMatchers("/adminScreen/**").hasRole("ADMIN")
			.and()
			.formLogin()
				.loginPage("/showLoginScreen")
				.loginProcessingUrl("/authenticateTheRole")
				.permitAll()
			.and()
			.logout().permitAll()
			.and()
			.exceptionHandling().accessDeniedPage("/access-denied");
		
	
		
}



}

