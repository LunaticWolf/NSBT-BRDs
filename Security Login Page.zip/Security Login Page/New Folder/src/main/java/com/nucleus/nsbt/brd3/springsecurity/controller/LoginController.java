package com.nucleus.nsbt.brd3.springsecurity.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class LoginController 
{

	@GetMapping("/showLoginScreen")
	//@RequestMapping("/showLoginScreen")
	public String showLoginScreen() 
	{

		return "login";
		
	}
	
	// add request mapping for /access-denied
	
	@GetMapping("/access-denied")
	//@RequestMapping("/access-denied")
	public String showAccessDenied() 
	{
		
		return "access-denied";
		
	}
	
}









