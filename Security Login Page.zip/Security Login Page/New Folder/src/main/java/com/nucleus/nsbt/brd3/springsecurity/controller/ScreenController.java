package com.nucleus.nsbt.brd3.springsecurity.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ScreenController 
{

	@GetMapping("/")
	//@RequestMapping("/")
	public String homeScreen() 
	{
		
		return "home";
	}
	
	// add request mapping for /leaders

	@GetMapping("/userScreen")
	//@RequestMapping("/leaders")
	public String adminScreen() 
	{
		
		return "userPage";
	}
	
	// add request mapping for /systems
	
	@GetMapping("/adminScreen")
	//@RequestMapping("/systems")
	public String userScreen() 
	{
		
		return "adminPage";
	}
	
}










