package com.nucleus.nsbt.brd3.springsecurity.config;

import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

public class SpringDispatcherServletInitializer extends AbstractAnnotationConfigDispatcherServletInitializer {

	//Basic's - 1 -> Set Servlet and class
	@Override
	protected Class<?>[] getRootConfigClasses()
	{
		return null;
	}

	
	//Basic's - 2 -> init param for ^ Servlet
	@Override
	protected Class<?>[] getServletConfigClasses() 
	{
		return new Class[] { AppConfig.class };
	}

	
	//Basic's - 3 -> Servlet Controller Mapping
	@Override
	protected String[] getServletMappings() {
		return new String[] { "/" };
	}

}






