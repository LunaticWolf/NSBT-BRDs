//Need To Change Properties file Class Path Line - 31




package com.nucleus.nsbt.brd3.springsecurity.config;

import java.beans.PropertyVetoException;
import java.util.logging.Logger;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import com.mchange.v2.c3p0.ComboPooledDataSource;




@Configuration
@EnableWebMvc    //Basics - 3 -> Validation,Conversion and Formatting Support 
@ComponentScan(basePackages="com.nucleus.nsbt.brd3.springsecurity.config")  //Basics - 4 -> Component Scan 
@PropertySource("classpath:persistence-mysql.properties") //Oracle Properties to define----------------
public class AppConfig {

	//Step - 1-->  property holder
	@Autowired
	private Environment env;
	
	
	//Step - 2(Optional) --> Logger
	private Logger logger = Logger.getLogger(getClass().getName());
	
	
	
	//Basic's - 5 - > View Resolver
	@Bean
	public ViewResolver viewResolver() {
		
		InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
		
		viewResolver.setPrefix("/WEB-INF/view/");
		viewResolver.setSuffix(".jsp");
		
		return viewResolver;
	}
	
	
	
	@Bean  //Security dataSource Bean
	public DataSource securityDataSource() 
	{
		
		// C3P0 creation
		ComboPooledDataSource securityDataSource
									= new ComboPooledDataSource();
				
		
		//Getting Connection
		// set the jdbc driver class
		try 
		{
			securityDataSource.setDriverClass(env.getProperty("jdbc.driver"));
		} 
		
		catch (PropertyVetoException exc) 
		{
			throw new RuntimeException(exc);
		}
		


		//Log Info
		logger.info(">>> jdbc.url=" + env.getProperty("jdbc.url"));
		logger.info(">>> jdbc.user=" + env.getProperty("jdbc.user"));
		
		
		
		
		// Set Database Connection
		
		securityDataSource.setJdbcUrl(env.getProperty("jdbc.url"));
		securityDataSource.setUser(env.getProperty("jdbc.user"));
		securityDataSource.setPassword(env.getProperty("jdbc.password"));
		
		
		
		// Set C3P0
		securityDataSource.setInitialPoolSize
		(
				
		getIntProperty("connection.pool.initialPoolSize"));

		securityDataSource.setMinPoolSize(getIntProperty("connection.pool.minPoolSize"));

		securityDataSource.setMaxPoolSize(getIntProperty("connection.pool.maxPoolSize"));

		securityDataSource.setMaxIdleTime(getIntProperty("connection.pool.maxIdleTime"));
		
		return securityDataSource;
	}
	
	
	private int getIntProperty(String propName) 
	{
		
		String propVal = env.getProperty(propName);
		int intPropVal = Integer.parseInt(propVal);
		return intPropVal;
	}
}
















